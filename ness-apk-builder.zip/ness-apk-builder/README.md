# NESS App — APK Builder

## How to get your APK in 5 minutes

### Step 1 — Go to GitHub
Visit https://github.com and sign in or create a free account.

### Step 2 — Create a new repository
- Click the green **New** button
- Name it: `ness-app`
- Set to **Public**
- Click **Create repository**

### Step 3 — Upload ALL files
Click **uploading an existing file** link on the new repo page.
Drag and drop ALL of these files maintaining the folder structure:

```
ness-app/
├── .github/
│   └── workflows/
│       └── build-apk.yml       ← the build robot
├── www/
│   └── index.html              ← your NESS app
├── capacitor.config.json
├── package.json
└── README.md
```

Click **Commit changes**.

### Step 4 — Watch it build
- Click the **Actions** tab at the top of your repo
- You'll see **Build NESS APK** running (yellow dot = building)
- Wait about **3-5 minutes**
- Green checkmark = done ✅

### Step 5 — Download your APK
- Click on the completed workflow run
- Scroll to the bottom — find **Artifacts**
- Click **NESS-App-v2.0-debug** to download
- You get a ZIP file — extract it to find **app-debug.apk**

### Step 6 — Install on Android
- Send the APK to your phone (WhatsApp, email, Google Drive)
- On your phone: Settings → Security → **Allow Unknown Sources**
- Open the APK file and tap Install
- NESS app appears on your home screen!

---

## Troubleshooting

**Build fails with Gradle error?**
- Check the Actions tab, click the failed run, expand the failing step
- Most common fix: the workflow retries automatically

**Can't install on phone?**
- Make sure "Install unknown apps" is enabled for your file manager
- Works on Android 6.0 and above

**Want a signed (release) APK?**
- The debug APK works fine for personal use and testing
- For Google Play Store, you'd need a signed release APK

---

App ID: com.ness.shop
Version: 2.0.0
Contact: onsarederrick@gmail.com | +254 715 261 211
